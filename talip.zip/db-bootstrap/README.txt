While running with docker, db-bootstrap folder can be used to bootstrap SQL data 
into the DB container when it is created. To do that, .sql or .sql.gz files should 
be placed into this folder.
For more information, please visit the brX docker documentation pages.
