package org.example.beans;

import org.hippoecm.hst.content.beans.Node;
import org.hippoecm.hst.content.beans.standard.HippoDocument;

@Node(jcrType="myproject:basedocument")
public class BaseDocument extends HippoDocument {

}
