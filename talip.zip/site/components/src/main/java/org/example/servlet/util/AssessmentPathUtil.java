package org.example.servlet.util;

public class AssessmentPathUtil {

	public static final String CONTENT = "/content";
	public static final String CONTENT_DOCUMENTS = CONTENT + "/documents";

}
